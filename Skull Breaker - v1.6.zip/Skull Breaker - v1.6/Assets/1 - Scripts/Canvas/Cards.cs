﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class Cards : MonoBehaviour {

    public GameObject player, item;

    // Use this for initialization
    void Start() {
        player = GameObject.Find("Player");
        int aux = Random.Range(0, player.GetComponent<Player>().baralho.Count); //Escolhe carta aleatória do baralho

        item = player.GetComponent<Player>().baralho[aux]; //Cria carta
        player.GetComponent<Player>().baralho.RemoveAt(aux); //Remove carta do baralho

        transform.Find("Image").GetComponent<Image>().sprite = item.GetComponent<SpriteRenderer>().sprite; //Desenha imagem do item
        transform.Find("Image").GetComponent<Image>().SetNativeSize(); // Ajusta size
        transform.Find("NameText").GetComponent<Text>().text = item.name; // Escreve nome

        //Armas
        if (item.tag == "Weapon")
        {
            if (item.GetComponent<Staff>()) // Se for um staff
                transform.Find("DamageText").GetComponent<Text>().text = item.GetComponent<Staff>().shot.GetComponent<Shot>().damage.ToString();//desenhar dano do tiro
            else
                transform.Find("DamageText").GetComponent<Text>().text = item.GetComponent<Weapon>().damage.ToString(); // Escreve dano
            transform.Find("EssenceText").GetComponent<Text>().text = item.GetComponent<Weapon>().cost.ToString(); // Escreve custo
        }
        //Torres
        else if (item.tag == "Tower")
        {
            transform.Find("Image").transform.localScale = new Vector3(0.8f, 0.8f, 0); //Ajusta size de torres
            if (item.GetComponent<Turret>()) // Se for um Turret
                transform.Find("DamageText").GetComponent<Text>().text = item.GetComponent<Turret>().shot.GetComponent<Shot>().damage.ToString(); //desenhar dano do tiro
            else
                transform.Find("DamageText").GetComponent<Text>().text = item.GetComponent<Tower>().damage.ToString(); // Escreve dano
            transform.Find("HealthText").GetComponent<Text>().enabled = true; // Liga texto vida
            transform.Find("HealthText").GetComponentInChildren<Image>().enabled = true; // Liga sprite vida
            transform.Find("HealthText").GetComponent<Text>().text = item.GetComponent<Tower>().health.ToString(); // Escreve vida
            transform.Find("EssenceText").GetComponent<Text>().text = item.GetComponent<Tower>().cost.ToString(); // Escreve custo
        }
        //Feitiço cura
        else if (item.tag == "HealSpell")
        {
            transform.Find("DamageText").GetComponent<Text>().color = new Color(0, 255, 0);
            transform.Find("DamageText").GetComponentInChildren<Image>().enabled = false; // Desliga sprite espada
            transform.Find("DamageText").GetComponent<Text>().text = item.GetComponent<Spell>().heal.ToString(); // Escreve dano
            transform.Find("EssenceText").GetComponent<Text>().text = item.GetComponent<Spell>().cost.ToString(); // Escreve custo
        }
    }

    // Destroi objeto
    public void Ativar()
    {
        if (item.tag == "Weapon")
        {
            //Se tem essencia o bastante para usar a carta
            if (player.GetComponent<Player>().qntEssence >= item.GetComponent<Weapon>().cost)
            {
                player.GetComponent<Player>().qntEssence -= item.GetComponent<Weapon>().cost; //Gasta essencia
                player.GetComponent<Player>().GainItem(item); //Cria item
                Destroy(gameObject); //Destroi carta
            }
        }
        else if (item.tag == "Tower")
        {
            //Se tem essencia o bastante para usar a carta
            if (player.GetComponent<Player>().qntEssence >= item.GetComponent<Tower>().cost)
            {
                player.GetComponent<Player>().qntEssence -= item.GetComponent<Tower>().cost; //Gasta essencia
                player.GetComponent<Player>().GainItem(item); //Cria item
                Destroy(gameObject); //Destroi carta
            }
        }
        else if (item.tag == "HealSpell")
        {
            //Se tem essencia o bastante para usar a carta
            if (player.GetComponent<Player>().qntEssence >= item.GetComponent<Spell>().cost)
            {
                player.GetComponent<Player>().qntEssence -= item.GetComponent<Spell>().cost; //Gasta essencia
                player.GetComponent<Player>().health += item.GetComponent<Spell>().heal;
                Destroy(gameObject); //Destroi carta
            }
        }
        player.GetComponent<Player>().ActiveMenu();
    }
}
