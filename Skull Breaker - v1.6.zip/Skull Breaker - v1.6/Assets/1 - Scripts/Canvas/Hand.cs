﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class Hand : MonoBehaviour {

    public List<Button> hand = null;
    public Button card;
    GameObject player;


    // Use this for initialization
    void Start () {
        player = GameObject.Find("Player");
        
        Button aux;
        while (hand.Count < 5)
        {
            aux = Instantiate(card, new Vector3(-98 + 49 * hand.Count,0,0), Quaternion.identity) as Button;
            aux.transform.SetParent(gameObject.transform, false);
            hand.Add(aux);
        }
    }

    void Update()
    {
        ////Remover cartas usadas
        //for (int i = 0; i < hand.Count; i++)
        //{
        //    if (hand[i] == null)
        //    {
        //        hand.RemoveAt(i);
        //    }
        //}
    }

    //Adiciona carta
    public void drawCard()
    {
        //Se a mão já está ativa
        if (gameObject.activeSelf)
        { 
            if (player.GetComponent<Player>().baralho.Count > 0) //Adiciona carta se tem cartas no baralho e mão não está cheia
            {
                for (int i = 0; i < hand.Count; i++) //Passa por todas aas posições na mão
                {
                    if (hand[i] == null) //Se tiver um lugar vazio
                    {
                        hand.RemoveAt(i); //remove carta usada
                        Button aux; 
                        aux = Instantiate(card, new Vector3(-98 + 49 * i, 0, 0), Quaternion.identity) as Button; // cria nova carta
                        aux.transform.SetParent(gameObject.transform.transform, false); //seta como filho
                        hand.Insert(i,aux); //insere no lugar da outra carta
                    }
                }
            }
        }
        //Se está desligado
        else
        {
            gameObject.SetActive(true); //liga
            if (player.GetComponent<Player>().baralho.Count > 0)
            {
                for (int i = 0; i < hand.Count; i++)
                {
                    if (hand[i] == null)
                    {
                        hand.RemoveAt(i);
                        Button aux;
                        aux = Instantiate(card, new Vector3(-98 + 49 * i, 0, 0), Quaternion.identity) as Button;
                        aux.transform.SetParent(gameObject.transform.transform, false);
                        hand.Insert(i, aux);
                    }
                }
            }
            gameObject.SetActive(false);//e depois desliga
        }
    }
}
