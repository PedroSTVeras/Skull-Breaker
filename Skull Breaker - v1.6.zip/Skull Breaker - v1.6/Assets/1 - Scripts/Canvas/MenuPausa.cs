﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine;

public class MenuPausa : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        PauseMenu();
    }

    //Pausa o jogo
    void PauseMenu()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            //Pausado
            if (Time.timeScale == 1)
            {
                GameObject.Find("CanvasMenuPausa").GetComponent<Canvas>().enabled = true;
                //GameObject.Find("CanvasMenuPausa").GetComponentInChildren<Text>().fontSize = 28;
                Time.timeScale = 0;
            }
            //Resume
            else if (Time.timeScale == 0)
            {
                ResumeGame();
            }
        }
    }

    //Resume o jogo
    public void ResumeGame()
    {
        GameObject.Find("CanvasMenuPausa").GetComponent<Canvas>().enabled = false;
        Time.timeScale = 1;
    }

    //Reinicia nível
    public void RestartGame()
    {
        SceneManager.LoadScene("Client");
        Time.timeScale = 1;
    }

    //Sai do jogo
    public void ExitGame()
    {
        Application.Quit();
    }
}
