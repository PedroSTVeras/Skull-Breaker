﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine;

public class Characters : MonoBehaviour {

    public float health, maxHealth;
    public GameObject arrow, alvo;
    public Image hpBar;
    public bool invincible = false, vivo = true;
    public SpriteRenderer sprRender;

    protected float vel_horizontal, vel_vertical;
    float invTimer = 0;
    bool blink = true;

    // Use this for initialization
    void Start () {
        health = maxHealth;
        //sprRender = GetComponent<SpriteRenderer>();
	}

    //Frames de invincibilidade
    public void invincibilityTimer(float invFrames)
    {
        //Checar se não está mais invencivel
        if (invincible)
        {
            //Checar se acabou o tempo
            invTimer += 1 * Time.deltaTime;
            //Piscar
            if (blink)
            {
                sprRender.color = new Color(255, 0, 0, 255);
                blink = false;
            }
            else {
                sprRender.color = new Color(255, 255, 255, 255);
                blink = true;
            }
            if (invTimer >= invFrames)
            {                
                invincible = false;
                invTimer = 0;
                sprRender.color = new Color(255, 255, 255, 255);
            }
        }
    }

    //Levar dano
    public void takeDmg(int hp, int knockback, GameObject target)
    {
        //Se não estiver invencível
        if (!invincible)
        {
            //Diminuir vida
            health -= hp;
            invincible = true;

            //Knockback
            alvo = target;
            float z = Mathf.Atan2((alvo.transform.position.y - transform.position.y), (alvo.transform.position.x - transform.position.x)) * Mathf.Rad2Deg - 90;
            arrow.transform.eulerAngles = new Vector3(0, 0, z);
            GetComponent<Rigidbody2D>().AddForce(-arrow.transform.up * knockback);
        }
    }
}
