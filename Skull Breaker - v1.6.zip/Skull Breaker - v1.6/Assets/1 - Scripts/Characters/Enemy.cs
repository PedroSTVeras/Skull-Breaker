﻿using System.Collections;
using System.Linq;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class Enemy : Characters
{
    int[] xDir = { 1, 1, 0, -1, -1, -1, 0, 1 };
    int[] yDir = { 0, -1, -1, -1, 0, 1, 1, 1 };
    GameObject player, nodoAux;
    
    List<GameObject> nodoAbertos;

    public GameObject essence, HPup;
    public float speed = 2.5f, auxSpeed;
    public int damage;

    // Use this for initialization
    void Start()
    {
        health = 100;
        player = GameObject.Find("Player");
        alvo = player;
        auxSpeed = speed;
    }

    //Colisão com player/Torre
    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.tag == "Player")
        {
            other.gameObject.GetComponent<Player>().takeDmg(damage, 180, gameObject);
        }
    }

    // Update is called once per frame
    void Update()
    {
        //Não rotacionar        
        transform.rotation = Quaternion.identity;
        vel_vertical = vel_horizontal = 0; //Zerar movimento

        if (alvo == null)
            alvo = player;

        //Frames de invincibilidade
        invincibilityTimer(0.4f);
        CheckDead();

        //Encontrar melhor caminho        
        movement();
        //encontrarCaminho();

    }

    //Seta velocidade e alvo
    public void setSpeedEAlvo(float speed, GameObject alvo)
    {
        this.speed = speed;
        this.alvo = alvo;
    }

    //Diminuir velocidade se chegar perto do player
    void speedControl()
    {
        if (Mathf.Abs(transform.position.x - alvo.transform.position.x) <= 0.6f && Mathf.Abs(transform.position.y - alvo.transform.position.y) <= 0.6f)
        {
            speed = 2.3f;
        }
        else
        {
            speed = auxSpeed;
        }
    }

    //Olhar player e movimentar
    void movement()
    {
        if (Time.timeScale == 1 && !invincible)
        {
            float z = Mathf.Atan2((alvo.transform.position.y - transform.position.y), (alvo.transform.position.x - transform.position.x)) * Mathf.Rad2Deg - 90;
            arrow.transform.eulerAngles = new Vector3(0, 0, z);
            GetComponent<Rigidbody2D>().AddForce(arrow.transform.up * speed);
        }
    }

    //Checa se está morto
    void CheckDead()
    {
        if (health <= 0)
        {
            int a = Random.Range(0, 6);
            if (a == 0)
                Instantiate(HPup, transform.position, Quaternion.identity);
            else
                Instantiate(essence, transform.position, Quaternion.identity);
            Destroy(gameObject);
        }
    }

    //A star
    public void encontrarCaminho()
    {
        nodoAbertos.Clear();        //Esvaziar lista

        for (int i = 0; i < 8; i++) //Nodo das outra posições adjacentes (começa a direita (oeste) e anda em sentido horário)
        {
            nodoAux.GetComponent<Nodo>().inicializar(transform.position.x + (xDir[i] * 0.1f), transform.position.y + (yDir[i] * 0.1f), i); //cria nodo na posição a ser testada
            nodoAux.GetComponent<Nodo>().calcularF(player.transform.position.x, player.transform.position.y); //Calcula o F
            nodoAbertos.Add(nodoAux);

            Debug.Log("1: " + nodoAbertos[i].GetComponent<Nodo>().getF());
        }

        // todos os elementos da lista de nodos abertos ficam iguais ao último elemento quando sai do for
        // não consegui arrumar isso

        for (int i = 0; i < 8; i++)
        {
            Debug.Log("2: " + nodoAbertos[i].GetComponent<Nodo>().getF());
        }
        Debug.Log("3: " + nodoAux.GetComponent<Nodo>().getF());


        //Pega o menor F
        vel_horizontal = xDir[nodoAux.GetComponent<Nodo>().getDirecao()] * speed * Time.deltaTime;
        vel_vertical = yDir[nodoAux.GetComponent<Nodo>().getDirecao()] * speed * Time.deltaTime;
        transform.position += new Vector3(vel_horizontal, vel_vertical, 0);
    }
}
