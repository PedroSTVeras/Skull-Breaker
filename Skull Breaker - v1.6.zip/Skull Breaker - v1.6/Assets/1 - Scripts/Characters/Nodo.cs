﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Nodo : MonoBehaviour
{
    float x, y;
    float valorG, valorF;
    int direcao;

    //Inicializa posição e se está a diagonal ou não
    public void inicializar(float x, float y, int g)
    {
        this.x = x;
        this.y = y;
        direcao = g;
        if (g % 2 == 0)
            valorG = 10.0f;
        else
            valorG = 14.0f;
    }

    //Retorna a heuristica (estimativa do melhor caminho
    float calculoHeuristica(float posXfinal, float posYfinal)
    {
        float distX, distY, dist;
        distX = posXfinal - x;
        distY = posYfinal - y;
        dist = Mathf.Abs(distX) + Mathf.Abs(distY);
        return dist/* * 10.0f*/;
    }

    //Calcula o F
    public void calcularF(float posXfinal, float posYfinal)
    {
        valorF = /*valorG + */calculoHeuristica(posXfinal, posYfinal);
    }

    //Retorna F
    public float getF()
    {
        return valorF;
    }

    //Retorna X
    public float getX()
    {
        return x;
    }

    //Retorna Y
    public float getY()
    {
        return y;
    }

    //Retorna direcao
    public int getDirecao()
    {
        return direcao;
    }
}
