﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class Player : Characters {
    
    public float speed = 2, percentHP;
    public int activeWep, qntEssence = 15, usedCards = 0;
    public Camera cam;
    public GameObject deck;
    public Button tab;
    public Image essenceCounter;
    public List<GameObject> baralho;
    public List<GameObject> weapons;
    public List<Sprite> sprites;
    public int cnnID = 1;

    int torresAtivas = 0, towerKills = 0, playerKills = 0; // Entrada no agenta analítico
    bool deckActive = false;

    // Use this for initialization
    void Start()
    {        
        maxHealth = 150;
    }

    //Ativa e desativa menu
    public void ActiveMenu()
    {
        deckActive = !deckActive;
    }

    //Choose weapon
    public void ChooseWeapon()
    {
        for (int i = 0; i < weapons.Count; i++)
        {
            if (Input.GetKey((i + 1).ToString()))
            {
                activeWep = i + 1;
            }
        }
    }

    //Adiciona item de carta
    public void GainItem(GameObject item)
    {
        //Cria nova arma
        if (item.tag == "Weapon")
        {
            GameObject aux = Instantiate(item, transform.position, Quaternion.identity) as GameObject;      //Cria nova arma
            aux.transform.SetParent(GameObject.Find("PlayerFace").transform, false);        //Seta como filho do player
            weapons.Add(aux);        //Adiciona na lista de armas
            activeWep = weapons.Count;        //Seta como arma ativa
        }
        //Cria nova torre
        else if (item.tag == "Tower" || item.tag == "Turret")
        {
            Instantiate(item, new Vector2(transform.position.x, transform.position.y + 0.3f), Quaternion.identity);      //Cria nova torre
            torresAtivas++;
        }
        usedCards++;
    }

    //Movimetação do player
    void Movement()
    {
        if (Input.GetKey("w"))
        {
            vel_vertical = speed * Time.deltaTime;
        }
        if (Input.GetKey("d"))
        {
            vel_horizontal = speed * Time.deltaTime;
        }
        if (Input.GetKey("s"))
        {
            vel_vertical = -speed * Time.deltaTime;
        }
        if (Input.GetKey("a"))
        {
            vel_horizontal = -speed * Time.deltaTime;
        }
        transform.position += new Vector3(vel_horizontal, vel_vertical, 0);
    }

    //Player Attack
    void Attack()
    {
        if (!deckActive && weapons.Count != 0) {
            if (weapons[activeWep - 1].GetComponent<Staff>()) {
                weapons[activeWep - 1].GetComponent<Staff>().atkAnimation();
            }
            else { 
                weapons[activeWep - 1].GetComponent<Weapon>().atkAnimation();
            }
        }
    }

    //Pegar posição do mouse e rotacionar
    void MousePosition()
    {
        //Não mexer se pausado
        if (Time.timeScale != 0)
        {
            //Pegar posição do mouse e rotacionar
            var mousePosition = cam.ScreenToWorldPoint(Input.mousePosition);
            Quaternion rot = Quaternion.LookRotation(arrow.transform.position - mousePosition, Vector3.forward);
            arrow.transform.rotation = rot;
            arrow.transform.eulerAngles = new Vector3(0, 0, arrow.transform.eulerAngles.z);
        }

        //Não mexer camera
        cam.transform.eulerAngles = new Vector3(0, 0, 0);
    }

    //Menu deck
    void DrawMenu()
    {
        //Tecla TAB
        if (Input.GetKeyDown(KeyCode.Tab))
        {
            ActiveMenu();
        }

        //Ativo/desativo
        deck.SetActive(deckActive);
    }

    //Checa se está morto
    void CheckDead()
    {
        if (health <= 0)
            vivo = false;
    }

    // Update is called once per frame
    void Update()
    {
        //Dados
        if (health > maxHealth)
            health = maxHealth;
        vel_vertical = vel_horizontal = 0;
        transform.rotation = Quaternion.identity;
        hpBar.GetComponent<Image>().fillAmount = health / maxHealth;
        percentHP = health / maxHealth;
        essenceCounter.transform.Find("Text").GetComponent<Text>().text = qntEssence.ToString();
        //gameObject.GetComponent<SpriteRenderer>().sprite = sprites[cnnID-1];//.Contains(0);

        if (vivo)
        {
            //Se não acabou de levar dano
            if (!invincible)
            {
                //Mouse Position
                MousePosition();

                //Movimentação
                Movement();
            }

            //Ativa/desativa menu deck
            DrawMenu();

            //Frames de invincibilidade
            invincibilityTimer(0.5f);
            CheckDead();

            //Escolhe arma
            ChooseWeapon();

            //Ataca com arma
            if (Input.GetMouseButtonDown(0))
            {
                Attack();

                //if (deckActive)
                //{
                //    deckActive = false;
                //}
            }
        }
    }
}
