﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using System.Text;
using UnityEngine.UI;

//Outros jogadores
public class OtherPlayers : MonoBehaviour
{
    public string playerName;
    public GameObject avatar;
    public int connectionID;
}

public class Client : MonoBehaviour {
    
    private int maxConnections = 2;
    private int port = 5701;

    private int hostID;
    private int connectionID;
    private int ourClientID;
    private int reliableChannelID, unreliableChannelID;

    private float connectTime;
    private bool connected = false;
    private bool started = false;
    private byte error;

    private string playerName;

    public GameObject game; //Onde roda o jogo
    public GameObject canvas; //Canvas inicial
    public GameObject playerPrefab; //Prefab dos outros jogadores
    public GameObject player; //Jogador
    public Dictionary<int, OtherPlayers> players = new Dictionary<int, OtherPlayers>(); //Lista de outros jogadores

    //Conectar
    public void Connect()
    {
        //Player name
        string name = GameObject.Find("NameInput").GetComponent<InputField>().text;
        if (name == "")
            return;
        playerName = name;
        
        NetworkTransport.Init();
        ConnectionConfig cconfig = new ConnectionConfig();

        reliableChannelID = cconfig.AddChannel(QosType.ReliableSequenced);
        unreliableChannelID = cconfig.AddChannel(QosType.Unreliable);

        HostTopology topology = new HostTopology(cconfig, maxConnections);
        hostID = NetworkTransport.AddHost(topology, 0);
        connectionID = NetworkTransport.Connect(hostID, "127.0.0.1", port, 0,out error);

        connected = true;
        connectTime = Time.time;

        //Desliga canvas e inicia o jogo
        StartGame();
    }

    private void Update()
    {
        //Não receber mensagens se n estiver conectado
        if (!connected)
            return;

        int recHostID;
        int connectionID;
        int channelID;
        byte[] recBuffer = new byte[1024];
        int bufferSize = 1024;
        int dataSize;
        byte error;
        NetworkEventType recData = NetworkTransport.Receive(out recHostID, out connectionID, out channelID, recBuffer, bufferSize, out dataSize, out error);

        switch (recData)
        {
            case NetworkEventType.DataEvent:
                string msg = Encoding.Unicode.GetString(recBuffer, 0, dataSize);
                Debug.Log("Receiving: " + msg);
                string[] splitData = msg.Split('|');

                switch (splitData[0])
                {
                    case "ASKNAME":
                        OnAskName(splitData);
                        break;

                    case "CNN":
                        SpawnPlayer(splitData[1], int.Parse(splitData[2]));
                        break;

                    case "DC":
                        PlayerDisconnected(int.Parse(splitData[1]));
                        break;

                    case "ASKPOSITION":
                        OnAskPosition(splitData);
                        break;

                    default:
                        break;
                }


                break;

        }
    }

    //Começo do jogo
    private void StartGame()
    {
        canvas.SetActive(false);
        game.SetActive(true);
        started = true;
    }

    //Servidor pediu nome
    private void OnAskName(string[] data)
    {
        //Setar o ID
        ourClientID = int.Parse(data[1]);
        player.GetComponent<Player>().cnnID = ourClientID; // manda o id da conexão para o script do player para desenhar o sprite certo

        //Mandar nome
        Send("NAMEIS|" + playerName, reliableChannelID);
        //Criar players
        for(int i = 2; i < data.Length - 1; i++)
        {
            string[] d = data[i].Split('%');
            SpawnPlayer(d[0], int.Parse(d[1]));
        }

    }

    //Servidor pediu posição
    private void OnAskPosition(string[] data)
    {
        if (!started)
            return;

        //Arrumar a posição dos outros
        for (int i = 1; i < data.Length - 1; i++)
        {
            string[] d = data[i].Split('%');
            if (ourClientID != int.Parse(d[0]))
            {
                Vector2 position = Vector2.zero;
                position.x = float.Parse(d[1]);
                position.y = float.Parse(d[2]);
                players[int.Parse(d[0])].avatar.transform.position = position;
            }
        }
        //Mandar a própria posição
        Vector2 mPos = player.transform.position;
        string m = "MYPOSITION|" + mPos.x.ToString() + '|' + mPos.y.ToString()+ '|';
        Send(m, unreliableChannelID);

    }

    //Spawnar jogadores
    private void SpawnPlayer(string playerName, int cnnID)
    {
        //Se o ID não é nosso, criar o outro player
        if (cnnID != ourClientID)
        {
            GameObject go = Instantiate(playerPrefab) as GameObject; //Instancia o outro jogador
            //go.transform.parent = game.transform; // faz ele filho do game 
            go.transform.position = new Vector3(5.5f,4.5f,0.0f);
            go.GetComponent<Player>().cnnID = cnnID; // manda o id da conexão para o script do outroplayer para desenhar o sprite certo

            OtherPlayers p = new OtherPlayers();
            p.avatar = go;
            p.playerName = playerName;
            p.connectionID = cnnID;
            players.Add(cnnID,p);
        }
    }

    //Jogador disconectou
    private void PlayerDisconnected(int cnnID)
    {
        Destroy(players[cnnID].avatar);
        players.Remove(cnnID);
    }

    //Manda mensagem para todos jogadores
    private void Send(string message, int channelID)
    {
        Debug.Log("Sending: " + message);
        byte[] msg = Encoding.Unicode.GetBytes(message);
        NetworkTransport.Send(hostID, connectionID, channelID, msg, message.Length * sizeof(char), out error);        
    }
}
