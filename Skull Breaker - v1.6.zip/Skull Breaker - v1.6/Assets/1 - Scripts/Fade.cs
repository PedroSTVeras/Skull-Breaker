﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class Fade : MonoBehaviour {

    Color auxColor;

    // Use this for initialization
    void Start () {
        gameObject.GetComponent<Image>().enabled = true;
        auxColor = GetComponent<Image>().color;
    }

    // Update is called once per frame
    void Update()
    {
        auxColor.a -= 1.0f * Time.deltaTime;
        gameObject.GetComponent<Image>().color = auxColor;
        if (gameObject.GetComponent<Image>().color.a <= 0)
        {
            Destroy(gameObject);
        }
        //Debug.Log(auxColor.a);
    }
}
