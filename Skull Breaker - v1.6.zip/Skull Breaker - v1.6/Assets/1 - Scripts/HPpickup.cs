﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HPpickup : MonoBehaviour {

    GameObject player;

    // Use this for initialization
    void Start()
    {
        player = GameObject.Find("Player");
    }

    // Update is called once per frame
    void Update()
    {

    }

    //Colisão com inimigo
    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.tag == "Player")
        {
            player.GetComponent<Player>().health += 10;
            Destroy(gameObject);
        }
    }
}
