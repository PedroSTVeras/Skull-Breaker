﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using UnityEngine;

public class Level : MonoBehaviour {

    public GameObject waveHUD, gameOver, enemy, hand;
    public List<int> waves; //Número de inimigos por wave (o tamanho é o número de waves)
    public List<GameObject> spawners; //Lista dos spawners no mapa
    public List<GameObject> enemies; //Lista de inimigos no mapa

    GameObject player;
    int currentWave = 1;
    float enemySpeed = 2.5f;
        
    // Use this for initialization
    void Start () {
        player = GameObject.Find("Player");
        hand = GameObject.Find("Hand");

        //gera primeira wave
        for (int j = 0; j < waves[currentWave - 1]; j++)
        {
            int a = Random.Range(0, (int)spawners.Count);
            enemies.Insert(j, Instantiate(enemy, new Vector2(spawners[a].transform.position.x + Random.Range(-0.2f, 0.2f),
                spawners[a].transform.position.y + Random.Range(-0.2f, 0.2f)), Quaternion.identity));
        }
    }
	
	// Update is called once per frame
	void Update () {
        //Player morreu
        if (!player.GetComponent<Player>().vivo)
        {
            gOver();
            gameOver.transform.Find("Text").GetComponent<Text>().text = "You lose!!!";
        }

        //Se não tem inimigos no jogo
        else if (enemies.Count == 0)
        {
            //Se não acabaram as waves
            if (currentWave < waves.Count)
            {                
                currentWave++; //Avança para próxima Wave
                SpawnWave(); //Determina stats da próxima wave e gera a nova wave
                hand.GetComponent<Hand>().drawCard(); //Compra carta
            }
            //Ganhou
            else
            {
                gOver();
                gameOver.transform.Find("Text").GetComponent<Text>().text = "You win!!!";
            }
        }

        //HUD
        if (player.GetComponent<Player>().vivo)
        {
            waveHUD.transform.Find("Text").GetComponent<Text>().text = "Wave: " + currentWave.ToString() + "/" + waves.Count.ToString();
            waveHUD.transform.Find("CurrentWave").GetComponent<Image>().fillAmount = (float)enemies.Count / (float)(waves[currentWave - 1]);
        }

        //Remover inimigos mortos
        for (int i = 0; i < enemies.Count; i++)
        {
            if (enemies[i] == null)
                enemies.RemoveAt(i);
        }
    }

    //GameOver
    void gOver()
    {
        waveHUD.SetActive(false);
        gameOver.SetActive(true);
    }

    //Cria wave
    void SpawnWave()
    {
        //Spawna inimigos
        for (int j = 0; j < waves[currentWave - 1]; j++)
        {
            int a = Random.Range(0, (int)spawners.Count);
            enemies.Insert(j, Instantiate(enemy, new Vector2(spawners[a].transform.position.x + Random.Range(-0.2f, 0.2f),
                spawners[a].transform.position.y + Random.Range(-0.2f, 0.2f)), Quaternion.identity));
        }
    }

    //Entrada: Inimigos mortos por torres, por players, vida do player, numero de cartas usadas    
    //void BalanceamentoDinamico()
    //{
    //    int aux = 0;
        
    //    //Muda a quantidade de inimgos que spawnam baseado em carta usadas e torres mortas
    //    if (player.GetComponent<Player>().usedCards > 2)
    //        aux += waves[currentWave - 1] / 2;
    //    else 
    //        aux -= waves[currentWave - 1] / 4;

    //    if (player.GetComponent<Player>().torresAtivas > 1)
    //        aux += waves[currentWave - 1] / 4;
    //    else if (player.GetComponent<Player>().torresAtivas < 1)
    //        aux -= waves[currentWave - 1] / 4;

    //    waves[currentWave - 1] += aux;

    //    //Debug.Log(waves[currentWave - 1]);

    //    //Muda velocidade dos inimigos
    //    if (player.GetComponent<Player>().percentHP > 0.6f)
    //        enemySpeed += 0.2f;
    //    else if (0.6f >= player.GetComponent<Player>().percentHP && player.GetComponent<Player>().percentHP > 0.3f)
    //        enemySpeed = 2.5f;
    //    else if (player.GetComponent<Player>().percentHP >= 0.3f)
    //        enemySpeed -= 0.3f;

    //    //Spawna inimigos
    //    for (int j = 0; j < waves[currentWave - 1]; j++)
    //    {
    //        int a = Random.Range(0, (int)spawners.Count);
    //        enemies.Insert(j,Instantiate(enemy, new Vector2(spawners[a].transform.position.x + Random.Range(-0.2f, 0.2f),
    //            spawners[a].transform.position.y + Random.Range(-0.2f, 0.2f)), Quaternion.identity));
    //        enemies[j].GetComponent<Enemy>().setSpeedEAlvo(enemySpeed, player);
    //    }
    //}   //Saida: numero de inimigos, velocidade inimigos, alvo dos inimigos
}
