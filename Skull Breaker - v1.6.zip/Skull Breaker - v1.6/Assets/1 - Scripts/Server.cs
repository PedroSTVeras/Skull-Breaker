﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using System.Text;

public class SvClient: MonoBehaviour
{
    public string playerName;
    public int connectionID;
    public Vector2 pos;
}

public class Server : MonoBehaviour
{
    private int maxConnections = 2;
    private int port = 5701;

    private int hostID;
    private int connectionID;
    private int reliableChannelID, unreliableChannelID;

    private bool started = false;
    private byte error;

    private List<SvClient> clients = new List<SvClient>();

    private float lastMovementUpdate;
    private float movementUpdate = 0.05f;

    //Conectar
    private void Start()
    {
        NetworkTransport.Init();
        ConnectionConfig cconfig = new ConnectionConfig();

        reliableChannelID = cconfig.AddChannel(QosType.ReliableSequenced);
        unreliableChannelID = cconfig.AddChannel(QosType.Unreliable);

        HostTopology topology = new HostTopology(cconfig, maxConnections);
        hostID = NetworkTransport.AddHost(topology, port, null);
        started = true;
    }

    private void Update()
    {
        //Não receber mensagens se n estiver iniciado
        if (!started)
            return;

        int recHostID; 
        int connectionID; //ID do cliente
        int channelID; //tipo de canal
        byte[] recBuffer = new byte[1024]; //mensagem
        int bufferSize = 1024; //tam da mensagem
        int dataSize;
        byte error;
        NetworkEventType recData = NetworkTransport.Receive(out recHostID, out connectionID, out channelID, recBuffer, bufferSize, out dataSize, out error);

        switch (recData)
        {
            case NetworkEventType.ConnectEvent:
                Debug.Log("Player " + connectionID + " has connected");
                OnConnection(connectionID); //Player has connected
                break;
            case NetworkEventType.DataEvent:
                string msg = Encoding.Unicode.GetString(recBuffer, 0, dataSize);
                Debug.Log("Receiving from " + connectionID + ": " + msg);
                string[] splitData = msg.Split('|');

                switch (splitData[0])
                {
                    case "NAMEIS":
                        OnNameIs(connectionID, splitData[1]);
                        break;

                    case "MYPOSITION":
                        OnMyPosition(connectionID, float.Parse(splitData[1]), float.Parse(splitData[2]));
                        break;

                    default:
                        break;
                }
                break;
            case NetworkEventType.DisconnectEvent:
                Debug.Log("Player " + connectionID + " has disconnected");
                OnDisconnection(connectionID);
                break;
        }

        //Pegar posição dos players
        if (Time.time - lastMovementUpdate > movementUpdate)
        {
            lastMovementUpdate = Time.time;
            string m = "ASKPOSITION|";
            foreach(SvClient sc in clients)
                m += sc.connectionID.ToString() + '%' + sc.pos.x.ToString() + '%' + sc.pos.y.ToString() + '|';
            m = m.Trim('|');
            Send(m, unreliableChannelID, clients);
        }

    }

    //Quando um jogador entra
    private void OnConnection(int cnnID)
    {
        //Add na lista
        SvClient c = new SvClient();
        c.connectionID = cnnID;
        c.playerName = "TEMP";
        clients.Add(c);

        //Informa o ID e nome dos jogadores
        string msg = "ASKNAME|" + cnnID + "|";
        foreach (SvClient sc in clients)
            msg += sc.playerName + '%' + sc.connectionID + '|';
        msg = msg.Trim('|');

        Send(msg, reliableChannelID, cnnID);
    }

    //Quando um jogador sai
    private void OnDisconnection(int cnnID)
    {
        clients.Remove(clients.Find(x => x.connectionID == cnnID));
        Send("DC|" + cnnID, reliableChannelID, clients);
    }

    //Quando recebe o nome do jogador
    private void OnNameIs(int cnnID, string playerName)
    {
        //Linkar nome com o id
        clients.Find(x => x.connectionID == cnnID).playerName = playerName;

        //Informar todos jogadores da nova conexão
        Send("CNN|" + playerName + '|' + cnnID, reliableChannelID, clients);
    }

    //Quando recebe a posição de um jogador
    private void OnMyPosition(int cnnID, float x, float y)
    {
        clients.Find(c => c.connectionID == cnnID).pos = new Vector2(x, y);
    }

    //Mandar mensgem para um jogador
    private void Send(string message, int channelID, int cnnID)
    {
        List<SvClient> c = new List<SvClient>();
        c.Add(clients.Find(x => x.connectionID == cnnID));
        Send(message, channelID, c);
    }
    //Mandar mensagem para todos jogadores
    private void Send(string message, int channelID, List<SvClient> c)
    {
        Debug.Log("Sending: " + message);
        byte[] msg = Encoding.Unicode.GetBytes(message);
        foreach(SvClient sc in c)
        {
            NetworkTransport.Send(hostID, sc.connectionID, channelID, msg, message.Length * sizeof(char), out error);
        }
    }
}