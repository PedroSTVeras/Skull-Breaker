﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tower : Characters
{
    public int damage, knockback, cost;

    // Use this for initialization
    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {
        transform.rotation = Quaternion.identity;
        invincibilityTimer(0);
        CheckDead();
    }

    //Colisão com inimigo
    protected void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.tag == "Enemy")
        {
            other.gameObject.GetComponent<Enemy>().takeDmg(damage, knockback, gameObject);
            takeDmg(other.gameObject.GetComponent<Enemy>().damage, 0, gameObject);
        }
    }

    //Checa se está morto
    protected void CheckDead()
    {
        if (health <= 0)
        {
            Destroy(gameObject);
        }
    }
}
