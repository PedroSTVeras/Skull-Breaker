﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Turret : Tower {

    public GameObject shot;

    GameObject enemy;
    float shotTimer = 1;
    bool temAlvo = false;

	// Use this for initialization
	void Start () {
        //damage = shot.GetComponent<Shot>().damage;
	}

    //Colisão com player
    new void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.tag == "Enemy" && !temAlvo)
        {
            enemy = other.gameObject;
            temAlvo = true;
        }
    }

    // Update is called once per frame
    void Update () {
        transform.rotation = Quaternion.identity;
        invincibilityTimer(0.5f);
        CheckDead();

        //Se inimigo morrer
        if (enemy == null)
        {
            enemy = new GameObject();
            temAlvo = false;
        }

        if (temAlvo)
        {
            //Olhar inimigo
            float z = Mathf.Atan2((enemy.transform.position.y - transform.position.y), (enemy.transform.position.x - transform.position.x)) * Mathf.Rad2Deg - 90;
            arrow.transform.eulerAngles = new Vector3(0, 0, z);

            //Atirar
            shotTimer += 1 * Time.deltaTime;
            if (shotTimer >= 1)
            {
                Instantiate(shot, transform.position, Quaternion.identity).GetComponent<Shot>().changeDirection(new Vector3(0.0f, 0.0f));
                shotTimer = 0;
            }
        }
    }
}
