﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TurretColision : MonoBehaviour {

    public GameObject turret;

	// Use this for initialization
	void Start () {
		
	}

    //Colisão com inimigo
    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.tag == "Enemy")
        {
            other.gameObject.GetComponent<Enemy>().takeDmg(0, 120, gameObject);
            turret.GetComponent<Turret>().takeDmg(other.gameObject.GetComponent<Enemy>().damage, 0, gameObject);
        }
    }
}
