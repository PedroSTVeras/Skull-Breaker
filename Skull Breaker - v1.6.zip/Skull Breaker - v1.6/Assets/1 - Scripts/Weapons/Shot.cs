﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shot : MonoBehaviour {

    public int damage = 15, knockback = 0;
    public float speed = 30;
    public new string name;

    bool canMove = false;
    GameObject shooter;
    Vector3 dir, bend;
    
    // Use this for initialization
    void Start()
    {
        shooter = GameObject.Find(name);
        dir = shooter.transform.Find("Face").up;
    }

    // Update is called once per frame
    void Update()
    {
        if (canMove)
        {
            //Movimenta
            if (Time.timeScale == 1)
            {
                GetComponent<Rigidbody2D>().AddForce((dir + bend) * speed);
            }
            //Destroy
            if (transform.position.y > 10 || transform.position.y < -10 || transform.position.x > 10 || transform.position.x < -10)
            {
                Destroy(gameObject);
            }
        }
    }

    //Mudar direcao
    public void changeDirection(Vector3 vec)
    {
        bend = vec;
        //transform.eulerAngles = vec;
        canMove = true;
    }

    //Colisão com inimigo
    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.tag == "Enemy")
        {
            other.gameObject.GetComponent<Enemy>().takeDmg(damage,knockback, shooter);
            Destroy(gameObject);
        }
    }
}
