﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Staff : Weapon {

    public GameObject shot;

    // Update is called once per frame
    protected new void Update()
    {
        auxToggle.transform.position = new Vector3((player.GetComponent<Player>().weapons.Count - id) * -100 + x, y);
        canShoot += 1 * Time.deltaTime;
        select();
    }

    //Ataque
    public new void atkAnimation()
    {
        if (canShoot >= fireRate)
        {
            anim.SetTrigger("Attack");
            Instantiate(shot, player.transform.position, Quaternion.identity).GetComponent<Shot>().changeDirection(new Vector3( 0.0f, 0.0f));
            //Instantiate(shot, player.transform.position, Quaternion.identity).GetComponent<Shot>().changeDirection(new Vector3( 0.5f, 0.0f));
            //Instantiate(shot, player.transform.position, Quaternion.identity).GetComponent<Shot>().changeDirection(new Vector3(-0.5f, 0.0f));
            canShoot = 0;
        }        
    }
    //Colisão com inimigo
    protected new void OnTriggerEnter2D(Collider2D other)
    {
    }
}
