﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class Weapon : MonoBehaviour {

    public int damage, knockback, cost;
    public Toggle toolbar;

    public float fireRate = 0.8f;
    public float canShoot;

    protected GameObject player;
    protected Animator anim;
    protected Toggle auxToggle;
    protected int id;
    protected float x, y;

    // Use this for initialization
    protected void Start () {
        player = GameObject.Find("Player");
        canShoot = fireRate;
        anim = GetComponentInParent<Animator>();
        id = player.GetComponent<Player>().weapons.Count;

        //Cria botão na HUD
        auxToggle = Instantiate(toolbar, toolbar.transform.position, Quaternion.identity) as Toggle;
        auxToggle.transform.SetParent(GameObject.Find("CanvasInterface").transform, false);
        auxToggle.transform.Find("Image").GetComponent<Image>().sprite = GetComponent<SpriteRenderer>().sprite;
        auxToggle.transform.Find("Image").GetComponent<Image>().SetNativeSize();
        auxToggle.transform.Find("Text").GetComponent<Text>().text = id.ToString();
        x = auxToggle.transform.position.x;
        y = auxToggle.transform.position.y;
    }

    // Update is called once per frame
    protected void Update () {
        auxToggle.transform.position = new Vector3((player.GetComponent<Player>().weapons.Count - id) * -100 + x, y);
        canShoot += 1 * Time.deltaTime;
        select();
    }

    //Selected
    protected void select()
    {
        if (id == player.GetComponent<Player>().activeWep)
        {
            auxToggle.GetComponent<Toggle>().isOn = true;
        }
        else
        {
            auxToggle.GetComponent<Toggle>().isOn = false;
        }
    }

    //Ataque
    public void atkAnimation()
    {
        if (canShoot >= fireRate)
        {
            anim.SetTrigger("Attack");
            canShoot = 0;
        }
    }

    //Colisão com inimigo
    protected void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.tag == "Enemy")
        {
            other.gameObject.GetComponent<Enemy>().takeDmg(damage, knockback,GameObject.Find("Player"));
        }
    }
}
